#!/usr/bin/env python
# coding: utf-8

# In[1]:


from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold


# In[2]:


import numpy as np
import pandas as pd


# In[3]:


np.random.seed(7)
df =  pd.read_csv("gs://vertex_custom_learning/IRIS.csv")


# In[4]:


df


# In[5]:


X = df.drop(["species"],axis=1)
Y = df['species'].map({'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2})


# In[6]:


encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

dummy_y = np_utils.to_categorical(encoded_Y)


# In[7]:


model = Sequential()
model.add(Dense(8, input_dim=4, activation='relu'))
model.add(Dense(3, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])


# In[8]:


model.fit(X, dummy_y, epochs=150, batch_size=5)


# In[9]:


scores = model.evaluate(X, dummy_y)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))


# In[10]:


predictions = model.predict(X)


# In[11]:


test = np.argmax(predictions,axis=1)
test


# In[12]:


model.save('gs://vertex_custom_learning/model_output')


# In[ ]:




